#!/bin/bash
# M8 S7 E04 Physics-STD toy acceptance: seed 2026 run B, one OS process -- execution authority d5d0cb3ea5d2c15aba4d0d2ddb84cade72ef279d
date -u +%FT%TZ > /home/student20261/workdir/m8s7_E04_s2026_B.launch_time
( while [ ! -s /home/student20261/workdir/m8s7_E04_s2026_B.end_time ]; do nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader,nounits | sed "s/^/$(date -u +%FT%TZ), /" >> /home/student20261/workdir/m8s7_E04_s2026_B.gpu_samples.tsv; sleep 2; done ) &
cd /home/student20261/workdir/m8_learned_banks/clones/s7e04_d5d0cb3ea5d2c15aba4d0d2ddb84cade72ef279d && env -i HOME=/home/student20261 PATH=/usr/bin:/bin LANG=C.UTF-8 CUBLAS_WORKSPACE_CONFIG=:4096:8 CUDA_VISIBLE_DEVICES=0 NVIDIA_TF32_OVERRIDE=0 PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 TF_CUDNN_DETERMINISTIC=1 TF_DETERMINISTIC_OPS=1 TF_ENABLE_AUTO_MIXED_PRECISION=0 TF_ENABLE_AUTO_MIXED_PRECISION_GRAPH_REWRITE=0 TF_ENABLE_CUBLAS_TENSOR_OP_MATH_FP32=0 TF_ENABLE_CUDNN_RNN_TENSOR_OP_MATH_FP32=0 TF_ENABLE_CUDNN_TENSOR_OP_MATH_FP32=0 TF_ENABLE_ONEDNN_OPTS=0 TF_XLA_FLAGS=--tf_xla_auto_jit=0 nice -n 10 /home/student20261/miniconda3/envs/gpat-m6-e03/bin/python -B tools/learned_bank.py s7 --method E04 --label B --out-root /home/student20261/workdir/m8_learned_banks/s7/d5d0cb3ea5d2c15aba4d0d2ddb84cade72ef279d/E04/seed_2026 --runtime-root /home/student20261/workdir/GPAT_TransferBench_runtime --seed 2026
echo $? > /home/student20261/workdir/m8s7_E04_s2026_B.exit
date -u +%FT%TZ > /home/student20261/workdir/m8s7_E04_s2026_B.end_time
wait
