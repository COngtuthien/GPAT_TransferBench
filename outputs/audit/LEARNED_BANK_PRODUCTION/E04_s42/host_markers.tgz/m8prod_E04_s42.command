#!/bin/bash
# M8 learned-bank production: method E04 seed 42, one OS process -- authority configs/amendments/learned_bank_production_E04.yaml at fabc1ef5069c05cd1d39e17057a90148fa296220
date -u +%FT%TZ > /home/student20261/workdir/m8prod_E04_s42.launch_time
cd /home/student20261/workdir/m8_learned_banks/clones/prod_E04_fabc1ef5069c05cd1d39e17057a90148fa296220 || { echo 97 > /home/student20261/workdir/m8prod_E04_s42.exit; exit 97; }
( while [ ! -s /home/student20261/workdir/m8prod_E04_s42.end_time ]; do nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader,nounits | sed "s/^/$(date -u +%FT%TZ), /" >> /home/student20261/workdir/m8prod_E04_s42.gpu_samples.tsv; sleep 5; done ) &
env -i HOME=/home/student20261 PATH=/usr/bin:/bin LANG=C.UTF-8 CUBLAS_WORKSPACE_CONFIG=:4096:8 CUDA_VISIBLE_DEVICES=0 NVIDIA_TF32_OVERRIDE=0 PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 TF_CUDNN_DETERMINISTIC=1 TF_DETERMINISTIC_OPS=1 TF_ENABLE_AUTO_MIXED_PRECISION=0 TF_ENABLE_AUTO_MIXED_PRECISION_GRAPH_REWRITE=0 TF_ENABLE_CUBLAS_TENSOR_OP_MATH_FP32=0 TF_ENABLE_CUDNN_RNN_TENSOR_OP_MATH_FP32=0 TF_ENABLE_CUDNN_TENSOR_OP_MATH_FP32=0 TF_ENABLE_ONEDNN_OPTS=0 TF_XLA_FLAGS=--tf_xla_auto_jit=0 nice -n 10 /home/student20261/miniconda3/envs/gpat-m6-e03/bin/python -B tools/learned_bank.py production --method E04 --seed 42 --runtime-root /home/student20261/workdir/GPAT_TransferBench_runtime
echo $? > /home/student20261/workdir/m8prod_E04_s42.exit
date -u +%FT%TZ > /home/student20261/workdir/m8prod_E04_s42.end_time
wait
