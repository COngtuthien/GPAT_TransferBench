#!/bin/bash
bash /home/student20261/workdir/m8_learned_banks/prod_scripts_fabc1ef5069c05cd1d39e17057a90148fa296220/m8prod_wait.sh E04 1337 14400 > /home/student20261/workdir/m8prod_E04_s1337_wait.log 2>&1
until [ "$(tmux list-panes -t m8prod_E04_s1337 -F '#{pane_dead}')" = 1 ]; do sleep 2; done
bash /home/student20261/workdir/m8_learned_banks/prod_scripts_fabc1ef5069c05cd1d39e17057a90148fa296220/m8prod_post.sh E04 1337 > /home/student20261/workdir/m8prod_E04_s1337_post.log 2>&1
env -i HOME=/home/student20261 PATH=/usr/bin:/bin LANG=C.UTF-8 CUDA_VISIBLE_DEVICES= nice -n 10 /home/student20261/miniconda3/envs/gpat-m6-e05/bin/python -I -B - collect --method E04 --seed 1337 --repo /home/student20261/workdir/m8_learned_banks/clones/prod_E04_fabc1ef5069c05cd1d39e17057a90148fa296220 < /home/student20261/workdir/m8_learned_banks/clones/prod_E04_fabc1ef5069c05cd1d39e17057a90148fa296220/tools/learned_bank_production_audit.py > /home/student20261/workdir/m8prod_E04_s1337_collected.json 2> /home/student20261/workdir/m8prod_E04_s1337_collect.err
echo $? > /home/student20261/workdir/m8prod_E04_s1337_collect.rc
chmod a-w /home/student20261/workdir/m8prod_E04_s1337_collected.json
